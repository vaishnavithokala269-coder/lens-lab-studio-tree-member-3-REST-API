# LensLab Studio – Member Contribution Overview

**Project Name:** LensLab Studio – Camera Rental Management System  
**GitHub Repository:** https://github.com/Nithish-2007-web/Lens-Lab-Studio  
**Team Member:** Vaishnavi (Member 3)  
**Assigned Role:** REST API Development  
**Assigned Git Branch:** `member-3-api`  

---

## 1. Executive Summary & Responsibilities

Member 3 (Vaishnavi) is responsible for REST API Endpoint implementation and database query execution across all business entities.
This includes:
- Photographer Management:
  - GET /photographers: Retrieves all registered photographers (200 OK).
  - POST /photographers: Registers a photographer with unique email constraint check (201 Created / 409 Conflict).
- Camera Management (CRUD):
  - GET /cameras: Returns all cameras or delegates to parameterized filtering (200 OK).
  - GET /cameras/:id: Fetches a single camera by ID with 404 handling if not found (200 OK / 404 Not Found).
  - POST /cameras: Inserts a validated camera record (201 Created).
  - PUT /cameras/:id: Updates an existing camera's details (200 OK / 404 Not Found).
  - DELETE /cameras/:id: Deletes a camera with foreign key rental conflict protection (200 OK / 404 Not Found / 409 Conflict if rented).
- Rental Management:
  - GET /rentals: Executes a 3-table SQL INNER JOIN (rentals JOIN photographers JOIN cameras) returning enriched rental records with names, rates, and dates (200 OK).
  - POST /rentals: Creates rental records and updates camera availability status (201 Created).
- Parameterized SQL queries preventing SQL injection across all operations.

---

## 2. Officially Owned Files

The following files are officially authored and maintained by **Vaishnavi**:

| File Path | Category | Description |
|---|---|---|
| `endpoints.js` | Source Code | REST API route handlers for photographers, camera CRUD, and rental transactions with relational SQL queries and HTTP status codes. |

### Detailed Component Overview

#### `endpoints.js`
- **Category:** Source Code
- **Role in System:** REST API route handlers for photographers, camera CRUD, and rental transactions with relational SQL queries and HTTP status codes.
- **Architectural Notes:** Implemented strictly within the assigned boundary of `member-3-api`. Ensures high cohesion and minimal tight coupling with other modules.


---

## 3. Technologies & Standards

- **Runtime:** Node.js (v18+ recommended)
- **Framework:** Express.js (v4.18.2)
- **Database Engine:** SQLite3 (v5.1.7)
- **Architecture:** Modular MVC / Separation of Concerns
- **Code Style:** Clean CommonJS syntax, robust error handling, defensive input validation.

---

## 4. Supporting Files Included

To enable independent inspection, architecture comprehension, and local execution, this package includes supporting files from the project:

| File Path | Category | Purpose in Package |
|---|---|---|
| `server.js` | Supporting Code | Express server configuration and error handling middleware. |
| `routes.js` | Supporting Code | Modular API router dispatching requests to endpoints.js. |
| `database/database.js` | Supporting Code | SQLite database connection provider and relational schema. |
| `validation.js` | Supporting Code | Camera input validation middleware and search handler. |
| `summary.js` | Supporting Code | Camera summary aggregation handler. |
| `package.json` | Configuration | Project metadata and dependencies. |
| `package-lock.json` | Configuration | Deterministic dependency tree lockfile. |
| `.gitignore` | Configuration | Git repository ignore patterns. |

> **Note on Ownership:** Supporting files are included strictly for reference and local environment execution. They are officially owned and maintained by other designated team members per the project contribution guide.

---

## 5. System Integration & Architectural Flow

Vaishnavi's components integrate seamlessly into the overall LensLab Studio architecture:

1. **Bootstrap & Server Lifecycle:** `server.js` boots the application and waits for `database/database.js` to initialize tables.
2. **Routing:** Incoming HTTP requests enter `routes.js` which dispatches routes in priority order.
3. **Validation & Filtering:** Requests pass through `validation.js` before touching mutation handlers.
4. **Endpoint Execution:** `endpoints.js` and `summary.js` execute SQL queries against SQLite and return JSON responses.
5. **Quality Assurance:** `test.js`, `api.http`, and Postman collections verify that all endpoints respond according to contract specifications.

---

## 6. Verification and Execution Guide

To inspect and test this contribution locally:

1. **Prerequisites:**
   Ensure Node.js and npm are installed.

2. **Setup:**
   Place the files in a working directory. Install dependencies using the included `package.json`:
   ```bash
   npm install
   ```

3. **Start the Application:**
   ```bash
   npm start
   ```
   The server will start on `http://localhost:3000`.

4. **Run Automated Verification:**
   ```bash
   npm test
   ```
   All 17 integration tests will execute and confirm full system integrity.

---

## 7. Package Integrity Confirmation

- **No Repository Artifacts:** `.git/` directory is excluded.
- **No Dependencies Bundled:** `node_modules/` is excluded to prevent bloat.
- **No Generated Database Files:** Transient `*.db` files are excluded to ensure clean initialization.
- **No Sensitive Secrets:** No environment tokens or credentials are included.
